/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans;
import java.sql.*;
import javax.servlet.http.HttpSession;
/**
 *
 * @author sy
 */
public class blog {
    public String title;
    public String content;
    public int user_id;
    public int blog_id;
    public Connection conn;
    public Connection get_Connection()
    {
        Connection con=null;
        try
        {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_blog?user=root&password=admin");
        }
        catch(Exception e){}
        this.conn=con;
        return con;
    }
    public String list_all_blog(String user_id)
    {
        try{
        this.conn=get_Connection();
        Statement sql=this.conn.createStatement();
        ResultSet blog_rs=sql.executeQuery("select * from blog where user_id='"+user_id+"'");
        String outpagelist="";
        while(blog_rs.next())
        {
            outpagelist+="<a href='see_blog.jsp?blog_id="+blog_rs.getString("blog_id")+"'>"+blog_rs.getString("title")+"</a>";outpagelist+="<br/>";
            outpagelist+=blog_rs.getString("content");outpagelist+="<br/>";
            
        }
        return outpagelist+"lalala";
        }
        catch(Exception e){return e.toString();}
    }
    public String get_single_blog(String user_id, String blog_id)
    {
        String blog_outpage="";
        try
        {
            this.conn=get_Connection();
            Statement sql=this.conn.createStatement();
            ResultSet blog=sql.executeQuery("select * from blog where user_id='"+user_id+"' and blog_id='"+blog_id+"'");      
            blog.next();
            blog_outpage+=blog.getString("title")+"<br/>";
            blog_outpage+=blog.getString("content")+"<hr/>";
        }
        catch(Exception e){}
        return blog_outpage;
    }
}
