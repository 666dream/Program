/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans;
import java.util.ArrayList;
import java.sql.*;
import javax.servlet.http.HttpSession;
/**
 *
 * @author sy
 */
public class comment {
    public String comment_id;
    public String username;
    public String blog_id;
    public String body;
    public String user_id;
    public String created_time;
    public Connection conn;
     public Connection get_Connection()
    {
        Connection con=null;
        try
        {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_blog?user=root&password=admin");
        }
        catch(Exception e){}
        this.conn=con;
        return con;
    }
    public ArrayList list_all_comment(String blog_id)
    {
        ArrayList all_comment=new ArrayList<comment>();
        try
        {
            this.conn=get_Connection();
            Statement sql=this.conn.createStatement();
          //  ResultSet comments_set=sql.executeQuery("select * from comment where blog_id='"+blog_id+"'");
            ResultSet comments_set=sql.executeQuery("select userinfo.username,comment.* from userinfo,comment,blog where userinfo.user_id=comment.user_id and blog.blog_id=comment.blog_id and blog.blog_id='"+blog_id+"'");
            while(comments_set.next())
            {
                comment cmt=new comment();
                cmt.blog_id=comments_set.getString("blog_id");
                cmt.comment_id=comments_set.getString("comment_id");
                cmt.body=comments_set.getString("body");
                cmt.created_time=comments_set.getString("created_time");
                cmt.user_id=comments_set.getString("user_id");
                cmt.username=comments_set.getString("username");
                all_comment.add(cmt);
            }
        }
        catch(Exception e){}
        return all_comment;
    }
    public String get_Username(String blog_id)
    {
        String username="";
        try
        {
            this.conn=get_Connection();
            Statement sql=this.conn.createStatement();
            ResultSet username_set=sql.executeQuery("select userinfo.username,comment.* from userinfo,comment,blog where userinfo.user_id=comment.user_id and blog.comment_id=comment.comment_id and blog.blog_id='"+blog_id+"'");
            username_set.next();
            username=username_set.getString("username");
        }
        catch(Exception e){}
        return username;
    }
}
